# Saiful Othman BBMA V1 — Build APK guna telefon sahaja

## 1. Upload ke GitHub
- Buka GitHub dalam Chrome Android.
- Buat repository baru, contoh: `SaifulOthmanBBMA`.
- Extract ZIP ini dahulu jika GitHub meminta fail projek secara terus. Struktur repository mesti bermula dengan `app/`, `build.gradle`, `settings.gradle`, dan `.github/`.
- Upload semua fail/folder projek dan commit ke `main`.

## 2. Build APK
- Buka tab **Actions** repository.
- Pilih **Build Saiful Othman BBMA APK**.
- Tekan **Run workflow**.
- Tunggu sehingga job bertanda hijau / Success.

## 3. Download APK
- Buka run yang berjaya.
- Scroll ke **Artifacts**.
- Download `SaifulOthmanBBMA-debug-apk`.
- Extract ZIP artifact dan ambil `app-debug.apk`.

## 4. Install
- Tekan `app-debug.apk`.
- Jika Android menyekat pemasangan, benarkan **Install unknown apps** untuk Chrome atau Files.
- Tekan Install.

Nota: APK ini ialah debug build untuk penggunaan/percubaan. Aplikasi V1 ialah prototype dan belum disambungkan kepada broker/MT5 atau data pasaran live.
